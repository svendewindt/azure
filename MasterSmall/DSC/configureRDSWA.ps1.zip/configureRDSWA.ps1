﻿configuration configureRDSWA
{
    param(
        [String]$nodeName = "localhost"
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $nodeName
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        WindowsFeature RDS-Web-Access
        {
            Ensure = "Present"
            Name = "RDS-Web-Access"
        }

        WindowsFeature RDS-Gateway
        {
            Ensure = "Present"
            Name = "RDS-Gateway"
        }
        
        WindowsFeature RSAT-RDS-Gateway
        {
            Ensure = "Present"
            Name = "RSAT-RDS-Gateway"
        }
    }
}

