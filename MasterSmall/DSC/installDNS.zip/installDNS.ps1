﻿configuration DNS{
    param(
        [String]$nodeName = "localhost"

    )

        Import-DscResource -module xNetworking
        $Interface = Get-NetAdapter| Where Name -Like "Ethernet*" | Select-Object -First 1
        $InteraceAlias = $($Interface.Name)

        node $nodeName{
        WindowsFeature RSAT
        {
            Ensure = "present"
            Name = "RSAT-dns-server"
        }

        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"
            IncludeAllSubFeature = $true                                                                                                                              
        }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $InteraceAlias
            AddressFamily  = 'IPv4'
        }

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
    }
}

