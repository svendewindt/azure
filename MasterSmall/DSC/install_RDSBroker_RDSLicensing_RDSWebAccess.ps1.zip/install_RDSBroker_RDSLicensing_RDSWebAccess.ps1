﻿
configuration BrokerLicensingWebAccess{
    param(
        [String]$nodeName = "localhost"
    )
    
    Import-DscResource –ModuleName ’PSDesiredStateConfiguration’

        node $nodeName{

        WindowsFeature RDS-Licensing
        {
            Ensure = "Present"
            Name = "RDS-Licensing"
        }

        WindowsFeature RDS-Connection-Broker
        {
            Ensure = "Present"
            Name = "RDS-Connection-Broker"
        }

        WindowsFeature RDS-Web-Access
        {
            Ensure = "Present"
            Name = "RDS-Web-Access"
        }

        WindowsFeature RDS-Licensing-UI 
        {
            Ensure = "Present"
            Name = "RDS-Licensing-UI"

        }

        WindowsFeature RSAT-RDS-Tools
        {
            Ensure = "Present"
            Name = "RSAT-RDS-Tools"
        }

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
    }
}

BrokerLicensingWebAccess
