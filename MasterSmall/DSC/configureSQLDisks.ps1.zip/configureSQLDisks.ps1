﻿Configuration setDisks{

    param(
        [String]$nodeName = "localhost"
    )

    Import-DscResource -moduleName cdisk, xdisk

    Node $nodeName{

    xWaitforDisk Disk2{
        DiskNumber = 2
        RetryIntervalSec = 5
        RetryCount = 30
    }

    cDiskNoRestart FData{
        DiskNumber = 2
        DriveLetter = 'F'
    }

    xWaitforDisk Disk3{
        DiskNumber = 3
        RetryIntervalSec = 5
        RetryCount = 30
    }

    cDiskNoRestart GLog{
        DiskNumber = 3
        DriveLetter = 'G'
    }

    xWaitforDisk Disk4{
        DiskNumber = 4
        RetryIntervalSec = 5
        RetryCount = 30
    }

    cDiskNoRestart HBackup{
        DiskNumber = 4
        DriveLetter = 'H'
    }

    }
}
