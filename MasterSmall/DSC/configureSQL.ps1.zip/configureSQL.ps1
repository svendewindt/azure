﻿Configuration configureSQL
{

    param(
        [String]$nodeName = "localhost",
        [Parameter(mandatory)][String]$domainName,
        [Parameter(mandatory)][System.Management.Automation.PSCredential]$Admincreds
    )

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    Import-DscResource -moduleName cdisk, xdisk, PSDesiredStateConfiguration, xComputerManagement

    Node $nodeName{

    LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        xComputer JoinDomain
        {
            Name = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $domaincreds
        }

    xWaitforDisk Disk2{
        DiskNumber = 2
        RetryIntervalSec = 5
        RetryCount = 30
    }

    cDiskNoRestart FData{
        DiskNumber = 2
        DriveLetter = 'F'
    }

    xWaitforDisk Disk3{
        DiskNumber = 3
        RetryIntervalSec = 5
        RetryCount = 30
    }

    cDiskNoRestart GLog{
        DiskNumber = 3
        DriveLetter = 'G'
    }

    xWaitforDisk Disk4{
        DiskNumber = 4
        RetryIntervalSec = 5
        RetryCount = 30
    }

    cDiskNoRestart HBackup{
        DiskNumber = 4
        DriveLetter = 'H'
    }

    }
 
}