﻿configuration configureRDS
{
    param(
        [String]$nodeName = "localhost",
        [Parameter(mandatory)][String]$domainName,
        [Parameter(mandatory)][System.Management.Automation.PSCredential]$Admincreds
        
    )

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Import-DscResource -ModuleName PSDesiredStateConfiguration, xComputerManagement

    Node $nodeName
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        xComputer JoinDomain{
            Name = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $DomainCreds
        }

        WindowsFeature RDS-RD-Server
        {
            Ensure = "Present"
            Name = "RDS-RD-Server"
            DependsOn = "[xComputer]JoinDomain" 
        }

        WindowsFeature RSAT-RDS-Licensing-Diagnosis-UI
        {
            Ensure = "Present"
            Name = "RSAT-RDS-Licensing-Diagnosis-UI"
            DependsOn = "[xComputer]JoinDomain" 
        }

        WindowsFeature desktop-experience
        {
            Ensure = "Present"
            Name = "desktop-experience"
            DependsOn = "[xComputer]JoinDomain" 
        }
        
    }
}
