﻿configuration configureRDS
{
    param(
        [String]$nodeName = "localhost"
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $nodeName
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        WindowsFeature RDS-RD-Server
        {
            Ensure = "Present"
            Name = "RDS-RD-Server"
        }

        WindowsFeature RSAT-RDS-Licensing-Diagnosis-UI
        {
            Ensure = "Present"
            Name = "RSAT-RDS-Licensing-Diagnosis-UI"
        }

        WindowsFeature desktop-experience
        {
            Ensure = "Present"
            Name = "desktop-experience"
        }
        
    }
}
